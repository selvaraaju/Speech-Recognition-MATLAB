% % Author : Dr. Selvaraaju Murugesan
% %  traning phase

clc; clear;close all
w = warning ('off','all');
Fs=8000;

filepart1='myrecordone';
filepart2='.wav';



% %  check for signal length
% length_all_sig=[];
% for i=1:10
%     filename=strcat(filepart1,num2str(i),filepart2);
%     y1=wavread(filename);
%     
%     results = VAD(y1,0.1,0.025,0.0125,20,1);
%     
%     ind_st=(0:size(results)-1)*200+1;
%     ind_en=(1:size(results))*200;
%     
%     ind1=ind_st(logical(results));
%     ind2=ind_en(logical(results));
%     
%     all_ind=cell2mat(arrayfun(@colon,ind1,ind2,'uni',0));
%     filt_signal=y1(all_ind);
%     
%     length_all_sig=[length_all_sig length(filt_signal)];
% end
% 
% max_length=max(length_all_sig);

all_data_one=[];

for i = 1:10
    filename=strcat(filepart1,num2str(i),filepart2);
    y1=wavread(filename);
    
%     results = VAD(y1,0.1,0.025,0.0125,20,1);
%     
%     ind_st=(0:size(results)-1)*200+1;
%     ind_en=(1:size(results))*200;
%     
%     ind1=ind_st(logical(results));
%     ind2=ind_en(logical(results));
%     
%     all_ind=cell2mat(arrayfun(@colon,ind1,ind2,'uni',0));
%     filt_signal=y1(all_ind);
%     
%     if length(filt_signal)==max_length
        [cepstra1,aspectrum,pspectrum] = melfcc(y1,Fs,'wintime',0.025,'hoptime',0.010);
%     else
%         filt_signal=[filt_signal' zeros(1,max_length-length(filt_signal))];
%         [cepstra,aspectrum,pspectrum] = melfcc(filt_signal,Fs,'wintime',0.025,'hoptime',0.010);           
%     end   
    
    all_data_one=[all_data_one cepstra1];
end

all_data_two=[];
filepart1='myrecordtwo';

for i = 1:10
    filename=strcat(filepart1,num2str(i),filepart2);
    y1=wavread(filename);
    
%     results = VAD(y1,0.1,0.025,0.0125,20,1);
%     
%     ind_st=(0:size(results)-1)*200+1;
%     ind_en=(1:size(results))*200;
%     
%     ind1=ind_st(logical(results));
%     ind2=ind_en(logical(results));
%     
%     all_ind=cell2mat(arrayfun(@colon,ind1,ind2,'uni',0));
%     filt_signal=y1(all_ind);
%     
%     if length(filt_signal)==max_length
        [cepstra2,aspectrum,pspectrum] = melfcc(y1,Fs,'wintime',0.025,'hoptime',0.010);
%     else
%         filt_signal=[filt_signal' zeros(1,max_length-length(filt_signal))];
%         [cepstra,aspectrum,pspectrum] = melfcc(filt_signal,Fs,'wintime',0.025,'hoptime',0.010);           
%     end   
    
    all_data_two=[all_data_two cepstra2];
end

% X=[all_data_one'; all_data_two'];

X=[all_data_one'];
% modelidx = getmodelidx(model);
% models(modelidx).word = model;
options = statset('MaxIter',500,'Display','final');
% disp(['Starting GMM Training for: ' model]);
obj1 = gmdistribution.fit(X,8,'CovType',...
    'diagonal','Options',options);

X=[all_data_two'];

obj2 = gmdistribution.fit(X,8,'CovType',...
    'diagonal','Options',options);

% obj = gmdistribution.fit(X,8,'Options',options);

test_data=cepstra1';

[~,nlogl] = posterior(obj1,test_data)

[~,nlogl] = posterior(obj2,test_data)

test_data=cepstra2';

[~,nlogl] = posterior(obj1,test_data)

[~,nlogl] = posterior(obj2,test_data)


