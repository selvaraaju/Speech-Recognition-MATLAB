
% %  traning phase
% %  Record sound
clc; clear;close all
% Duration=2;
Fs=8000;
% disp('Record now')
% y=wavrecord(Duration*Fs,Fs);
% disp('Recording Finished')
% wavwrite(y,'myrecord.wav');
% plot(y)
y1=wavread('myrecord.wav');
sound(y1,Fs)

results = VAD(y1,0.1,0.025,0.0125,20,1);
plot(results)

ind_st=(0:size(results)-1)*200+1;
ind_en=(1:size(results))*200;

ind1=ind_st(logical(results));
ind2=ind_en(logical(results));

all_ind=cell2mat(arrayfun(@colon,ind1,ind2,'uni',0));
filt_signal=y1(all_ind);

figure;plot(y1)
figure;plot(filt_signal,'r')
sound(filt_signal,Fs)

[cepstra,aspectrum,pspectrum] = melfcc(filt_signal,Fs,'wintime',0.025,'hoptime',0.010);
