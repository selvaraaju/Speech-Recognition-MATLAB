% %  traning phase
% %  Record sound
% w = warning ('off','all');
% clc; clear;close all
% Duration=2;
% Fs=8000;
% filepart1='myrecordone';
% filepart2='.wav';
% for i = 1:10
%     disp('Record now'); 
%     y=wavrecord(Duration*Fs,Fs);
%     disp('Recording Finished');
%     filename=strcat(filepart1,num2str(i),filepart2);
%     wavwrite(y,Fs,filename);
% end


w = warning ('off','all');
clc; clear;close all
Duration=2;
Fs=8000;
filepart1='myrecordthree';
filepart2='.wav';
for i = 1:10
    disp('Record now'); 
    y=wavrecord(Duration*Fs,Fs);
    disp('Recording Finished');
    filename=strcat(filepart1,num2str(i),filepart2);
    wavwrite(y,Fs,filename);
end