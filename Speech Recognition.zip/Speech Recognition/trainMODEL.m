function [ ] = trainMODEL( y, model, zeroTHRESHOLD )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here


Fs = 8000;

yva = round(y*2^15);

load bpf125_750
yabs = abs(yva);
yafilt = filter(bpf125_750,1,yabs);
yafilt = yafilt(65:end);
yafilt = [yafilt;zeros(64,1)];

for i = 1: length(yafilt);
    if (abs(yafilt(i)) < zeroTHRESHOLD);
        yafilt(i) = 0;
    end
end


xcross = sign(yafilt);
VA = zeros(1,length(y));

for i = 1: length(yafilt);
    if xcross(i) == 1
        VA(i-160:i+640) = 1;
    end
end
VA = VA(1:length(y));
plot(y(1:end)),hold
plot(VA(1:end),'r'),hold

yVA = y.*VA';
plot(yVA)
yVA80 = yVA(81:end);

yVAmat = vec2mat(yVA,160);
yVA8mat = vec2mat(yVA80,160);

z = [yVAmat';yVA8mat'];
zvect = vec2mat(z',1);
plot(zvect)

VAframes = vec2mat(zvect,160);     

numFRAMES = fix(length(VAframes));
ALLdata = zeros(numFRAMES,160);

X = VAframes;
X = X(any(X,2),:);

ALLdata =X';
mfccdata = mfcc(ALLdata,Fs,1);

% Calculate a GMM fit for the training data and save to MODELS
if exist('MODELS.mat','file')
    load MODELS
end

modelidx = getmodelidx(model);
models(modelidx).word = model;
options = statset('MaxIter',500,'Display','final');
disp(['Starting GMM Training for: ' model]);
models(modelidx).gmm = gmdistribution.fit(mfccdata',8,'CovType',...
    'diagonal','Options',options);
save MODELS models

end
