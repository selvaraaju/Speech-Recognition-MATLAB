% % Author : Dr. Selvaraaju Murugesan
% %  traning phase
% %  Record sound
clc; clear;close all
Duration=1;
Fs=8000;
% disp('Record now')
% y=wavrecord(Duration*Fs,Fs);
% disp('Recording Finished')
% wavwrite(y,'myrecord.wav');

y1=wavread('myrecord.wav');
% sound(y1,Fs)

frame_on = VAD(y1,0.1,0.05,0.025,20,1);
frame_on = [0 0 frame_on'];

n1=1:400:80000;n1=[n1(1) n1(2:end)];
n2=400:400:80000; 

for i=1:length(frame_on)
    if frame_on(i)==0
        continue;
    else
        st_in=n1(i);
        en_in=n2(i);
        signal_ind=cell2mat(arrayfun(@colon,st_in,en_in,'Uni',0));
    end
end
